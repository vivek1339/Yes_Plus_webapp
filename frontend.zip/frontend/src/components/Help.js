import React from 'react';

var username = JSON.parse(localStorage.getItem('userdata'));

const HelpPage = () =>(
    <div>
        This is help.
    </div>
);

export default HelpPage;