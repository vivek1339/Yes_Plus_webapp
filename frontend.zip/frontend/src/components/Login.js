import React from 'react';
import Login from './login/Login';
import SignUp from './login/SignUp';
import Social1 from './Login/social1';



const Log = () =>(
    <div>
     <Login />
     <Social1 />
    </div>
)

export default Log;