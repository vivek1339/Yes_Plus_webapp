import React from 'react';
import SignUp from './Login/SignUp';
import Social1 from './login/social1';

const signup1 = () =>(
    <div>

        <SignUp />
        <Social1 />
        
    </div>
)

export default signup1;