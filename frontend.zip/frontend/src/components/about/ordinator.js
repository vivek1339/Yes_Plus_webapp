import React from 'react';

const Ordinator = () => {
    return(
        <div>
   
        </div>
    );
};

export default Ordinator;