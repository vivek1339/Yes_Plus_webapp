import React from 'react';
export default class welcoming extends React.Component{
    render() {
        return (
          <div className="yp_welcome">
              <center>
                  <h2 className="yp_first"> Welcome to </h2>
                  <h1 className="yp_second">Yes!+</h1>
                  <h2 className="yp_fourth">Club</h2>
                  <h3 className="yp_third"><b>Venue: Bangalore Institute Of Technology</b> </h3>
              </center>
          </div> 
        )
    }
}